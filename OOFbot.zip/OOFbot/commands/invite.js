module.exports.run = async(client,message,args) =>{
    message.channel.send(`I'm BETA BOT. So you can't invite me. :(`);
}

module.exports.help = {
    name: 'invite',
    aliases: ['&'],
    description: 'Invite link'
}