module.exports.run = async(client,message,args) =>{
    message.channel.send(`Commands: "oof", "help", "info", "ping", "invite", "image", "noob", "my_haters"`);
}

module.exports.help = {
    name: 'help',
    aliases: ['&'],
    description: 'BOT say all commands'
}