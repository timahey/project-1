module.exports.run = async(client,message,args) =>{
    message.channel.send(`Nah, i'm not noob. you re noob.`);
}

module.exports.help = {
    name: 'noob',
    aliases: ['&'],
    description: 'Yeah, noob'
}