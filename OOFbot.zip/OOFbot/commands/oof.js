module.exports.run = async(client,message,args) =>{
    message.channel.send(`OOF!`);
}

module.exports.help = {
    name: 'oof',
    aliases: ['&'],
    description: 'This BOT ready say: "oof"'
}