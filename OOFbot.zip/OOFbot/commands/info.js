module.exports.run = async(client,message,args) =>{
    message.channel.send(`Hello! I'm OOF Bot. My creator is: <@507301976141463552>. Well, good luck!`);
}

module.exports.help = {
    name: 'info',
    aliases: ['&'],
    description: 'Info about OOF BOT'
}