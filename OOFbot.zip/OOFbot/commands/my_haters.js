module.exports.run = async(client,message,args) =>{
    message.channel.send(`I'm don't have haters. Noice.`);
}

module.exports.help = {
    name: 'my_haters',
    aliases: ['&'],
    description: 'BOT say all haters'
}