module.exports.run = async(client,message,args) =>{
    message.channel.send(`Pong! \`${parseInt(client.ping)}\` ms`);
}

module.exports.help = {
    name: 'ping',
    aliases: ['&'],
    description: 'Ping command'
}