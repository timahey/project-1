module.exports.run = async(client,message,args) =>{
    message.channel.send(`https://cdn.wallpapersafari.com/35/25/dM3BDx.jpg`);
}

module.exports.help = {
    name: 'image',
    aliases: ['&'],
    description: 'OOF Image'
}