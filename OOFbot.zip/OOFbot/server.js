const { Client,Collection } = require('discord.js');
const fs = require('fs');
const client = new Client();

client.commands = new Collection();
client.login('NzI3MzM3NjE0ODM0OTI1NTc5.Xvqx2A.arx1G4OYjIq3P9-NlFaWTrPfGo4')
client.prefix = '&';
client.on('message', message =>{
    if (!message.content.startsWith(client.prefix)) return;
    if (message.author.bot || message.channel.type === 'dm') return;
    const args = message.content
    .slice(client.prefix.length)
    .trim()
    .split(/ + /g);

    let command = args.shift().toLowerCase();
    let cmd;
    if (client.commands.has(command)) {
        cmd = client.commands.get(command);
    }
    if (!cmd) return;
    cmd.run(client,message,args);
});

fs.readdir('./commands', (err, files) =>{
    if (err) console.log(err);
    let jusfile = files.filter(f =>f.split('.').pop() === 'js');

    if (jusfile.length <= 0) {
        console.log('Command not found')
        return;
    }

    jusfile.forEach ((f, i) =>{
        let props = require(`./commands/${f}`);
        if (props.help) client.commands.set(props.help.name, props);
        if (props.help && props.help.aliases) {
            if (!Array.isArray(props.help.aliases)) return;
            props.help.aliases.forEach(a =>{
                client.commands.set(a, props);
            });
        }
    })
})

client.on('ready', () =>{
    console.log(`${client.user.tag} Готов!`);
    client.user.setStatus("dnd")
    client.user.setActivity("Tries to learn how to moderate the servers.")
    });